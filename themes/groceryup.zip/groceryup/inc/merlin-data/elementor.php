<?php

class GroceryUp_Merlin_Elementor
{
    public function import_files_demo()
    {
        $rev_sliders = array(
            "https://sobatstartup.github.io/themes/groceryup/default/slider.zip",
            "https://sobatstartup.github.io/themes/groceryup/default/slider-banner.zip",
        );
    
        $data_url = "https://sobatstartup.github.io/themes/groceryup/default/data.xml";
        $widget_url = "https://sobatstartup.github.io/themes/groceryup/default/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo',
                'home'                       => 'home-i',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://sobatstartup.github.io/themes/groceryup/default/redux_options.json",
                        'option_name' => 'groceryup_sostar_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://sobatstartup.github.io/themes/groceryup/default/screenshot.png",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'groceryup'),
                'preview_url'                => 'https://themes.sobatstartup.com/groceryup/',
            ),
        );
    }

    public function import_files_demo_dokan()
    {
        $rev_sliders = array(
            "https://sobatstartup.github.io/themes/groceryup/default/dokan/slider.zip",
            "https://sobatstartup.github.io/themes/groceryup/default/dokan/slider-banner.zip",
        );
    
        $data_url = "https://sobatstartup.github.io/themes/groceryup/default/dokan/data.xml";
        $widget_url = "https://sobatstartup.github.io/themes/groceryup/default/dokan/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo DOKAN',
                'home'                       => 'home-i',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://sobatstartup.github.io/themes/groceryup/default/dokan/redux_options.json",
                        'option_name' => 'groceryup_sostar_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://sobatstartup.github.io/themes/groceryup/default/dokan/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'groceryup'),
                'preview_url'                => 'https://themes.sobatstartup.com/groceryup/',
            ),
        );
    }

    
    public function import_files_demo_wcmp()
    {
        $rev_sliders = array(
            "https://sobatstartup.github.io/themes/groceryup/default/wcmp/slider.zip",
            "https://sobatstartup.github.io/themes/groceryup/default/wcmp/slider-banner.zip",
        );
    
        $data_url = "https://sobatstartup.github.io/themes/groceryup/default/wcmp/data.xml";
        $widget_url = "https://sobatstartup.github.io/themes/groceryup/default/wcmp/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo WCMP',
                'home'                       => 'home-i',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://sobatstartup.github.io/themes/groceryup/default/wcmp/redux_options.json",
                        'option_name' => 'groceryup_sostar_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://sobatstartup.github.io/themes/groceryup/default/wcmp/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'groceryup'),
                'preview_url'                => 'https://themes.sobatstartup.com/groceryup/',
            ),
        );
    }

        
    public function import_files_demo_wcfm()
    {
        $rev_sliders = array(
            "https://sobatstartup.github.io/themes/groceryup/default/wcfm/slider.zip",
            "https://sobatstartup.github.io/themes/groceryup/default/wcfm/slider-banner.zip",
        );
    
        $data_url = "https://sobatstartup.github.io/themes/groceryup/default/wcfm/data.xml";
        $widget_url = "https://sobatstartup.github.io/themes/groceryup/default/wcfm/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo WCFM',
                'home'                       => 'home-i',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://sobatstartup.github.io/themes/groceryup/default/wcfm/redux_options.json",
                        'option_name' => 'groceryup_sostar_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://sobatstartup.github.io/themes/groceryup/default/wcfm/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'groceryup'),
                'preview_url'                => 'https://themes.sobatstartup.com/groceryup/',
            ),
        );
    }

    
    public function import_files_demo_wcvendors()
    {
        $rev_sliders = array(
            "https://sobatstartup.github.io/themes/groceryup/default/wcvendors/slider.zip",
            "https://sobatstartup.github.io/themes/groceryup/default/wcvendors/slider-banner.zip",
        );
    
        $data_url = "https://sobatstartup.github.io/themes/groceryup/default/wcvendors/data.xml";
        $widget_url = "https://sobatstartup.github.io/themes/groceryup/default/wcvendors/widgets.wie";
        

        return array(
            array(
                'import_file_name'           => 'Demo WCVENDORS',
                'home'                       => 'home-i',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://sobatstartup.github.io/themes/groceryup/default/wcvendors/redux_options.json",
                        'option_name' => 'groceryup_sostar_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://sobatstartup.github.io/themes/groceryup/default/wcvendors/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'groceryup'),
                'preview_url'                => 'https://themes.sobatstartup.com/groceryup/',
            ),
        );
    }
}

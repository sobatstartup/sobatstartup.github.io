<?php

/**
 * Set the content width based on the theme's design and stylesheet.
 *
 * @since GroceryUp 1.0
 */
define('GROCERYUP_THEME_VERSION', '1.0');

/**
 * ------------------------------------------------------------------------------------------------
 * Define constants.
 * ------------------------------------------------------------------------------------------------
 */
define('GROCERYUP_THEME_DIR', get_template_directory_uri());
define('GROCERYUP_THEMEROOT', get_template_directory());
define('GROCERYUP_IMAGES', GROCERYUP_THEME_DIR . '/inc/assets/images/core');
define('GROCERYUP_SCRIPTS', GROCERYUP_THEME_DIR . '/inc/assets/js');

define('GROCERYUP_STYLES', GROCERYUP_THEME_DIR . '/inc/assets/css');

define('GROCERYUP_INC', 'inc');
define('GROCERYUP_MERLIN', GROCERYUP_INC . '/merlin');
define('GROCERYUP_CLASSES', GROCERYUP_INC . '/classes');
define('GROCERYUP_VENDORS', GROCERYUP_INC . '/vendors');
define('GROCERYUP_CONFIG', GROCERYUP_VENDORS . '/redux-framework/config');
define('GROCERYUP_WOOCOMMERCE', GROCERYUP_VENDORS . '/woocommerce');
define('GROCERYUP_ELEMENTOR', GROCERYUP_THEMEROOT . '/inc/vendors/elementor');
define('GROCERYUP_ELEMENTOR_TEMPLATES', GROCERYUP_THEMEROOT . '/elementor_templates');
define('GROCERYUP_PAGE_TEMPLATES', GROCERYUP_THEMEROOT . '/page-templates');
define('GROCERYUP_WIDGETS', GROCERYUP_INC . '/widgets');

define('GROCERYUP_ASSETS', GROCERYUP_THEME_DIR . '/inc/assets');
define('GROCERYUP_ASSETS_IMAGES', GROCERYUP_ASSETS    . '/images');

define('GROCERYUP_MIN_JS', '');

if (! isset($content_width)) {
    $content_width = 660;
}

function groceryup_sostar_get_config($name, $default = '')
{
    global $groceryup_options;
    if (isset($groceryup_options[$name])) {
        return $groceryup_options[$name];
    }
    return $default;
}

function groceryup_sostar_get_global_config($name, $default = '')
{
    $options = get_option('groceryup_sostar_theme_options', array());
    if (isset($options[$name])) {
        return $options[$name];
    }
    return $default;
}

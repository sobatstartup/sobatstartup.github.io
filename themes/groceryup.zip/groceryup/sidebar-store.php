<?php
/**
 * The sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage GroceryUp
 * @since GroceryUp 1.0
 */


$sidebar = sostar_get_sidebar_dokan();

if(!isset($sidebar['id']) || empty($sidebar['id'])) return;

?> <div class="sostar-sidebar-vendor sidebar"><?php dynamic_sidebar( $sidebar['id'] ); ?></div>


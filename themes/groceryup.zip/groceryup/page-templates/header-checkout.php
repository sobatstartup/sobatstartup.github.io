<header id="sostar-header" class="sostar_header-template site-header header-checkout">
	<div class="container">
		<?php
			/**
			* groceryup_theme_header_checkout hook
			*
			* @hooked groceryup_the_logo_checkout - 10
			*/
			do_action('groceryup_theme_header_checkout');
		?>
	</div>
</header>
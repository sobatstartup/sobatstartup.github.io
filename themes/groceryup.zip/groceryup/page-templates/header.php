<?php

if( groceryup_checkout_optimized() ) {
	get_template_part('page-templates/header-checkout'); 
	return;
}

$header 	= apply_filters('groceryup_sostar_get_header_layout', 'header_default');

$class_header = groceryup_header_located_on_slider();
?>

<header id="sostar-header" class="sostar_header-template site-header <?php echo esc_attr($class_header) ?>">

	<?php if ($header != 'header_default') : ?>	

		<?php groceryup_sostar_display_header_builder(); ?> 

	<?php else : ?>
	
	<?php get_template_part('page-templates/header-default'); ?>

	<?php endif; ?>
	<div id="nav-cover"></div>
	<div class="bg-close-canvas-menu"></div>
</header>
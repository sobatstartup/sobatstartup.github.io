<?php 
    if ( has_nav_menu( 'primary' ) ) {
        $sostar_location = 'primary';
        $locations  = get_nav_menu_locations();
        $menu_id    = $locations[ $sostar_location ] ;
        $menu_obj   = wp_get_nav_menu_object( $menu_id );
        $menu_name  = groceryup_get_transliterate($menu_obj->slug);
    } else {
        $sostar_location = $menu_name = '';
    }
?>
<nav data-duration="400" class="hidden-xs hidden-sm sostar-megamenu slide animate navbar sostar-horizontal-default" data-id="'. $menu_name .'">
<?php
    $args = array(
        'theme_location' => 'primary',
        'menu_class' => 'nav navbar-nav megamenu',
        'fallback_cb' => '',
        'menu_id' => 'primary-menu', 
        'menu_class'  => 'nav navbar-nav megamenu menu',
    );

    $args['walker']             =   new GroceryUp_Megamenu_Walker();

    wp_nav_menu($args);
?>
</nav>
<?php

    $copyright 	= groceryup_sostar_get_config('copyright_text', '');

?>

<?php if (is_active_sidebar('footer')) : ?>
	<div class="footer">
		<div class="container">
			<div class="row">
				<?php dynamic_sidebar('footer'); ?>
			</div>
		</div>
	</div>
<?php endif; ?>

<?php if (!empty($copyright)) : ?>
	<div class="sostar-copyright">
		<div class="container">
			<div class="copyright-content">
				<div class="text-copyright text-center">
				
					<?php echo trim($copyright); ?>

				</div> 
			</div>
		</div>
	</div>

<?php else: ?>
	<div class="sostar-copyright">
		<div class="container">
			<div class="copyright-content">
				<div class="text-copyright text-center">
				<?php
                        $allowed_html_array = array( 'a' => array('href' => array() ) );
                        echo wp_kses(__('Copyright &copy; 2024 GroceryUp by <a href="//sobatstartup.com/">Sobat StartUp</a>. All Rights Reserved.', 'groceryup'), $allowed_html_array);
                    
                ?>

				</div> 
			</div>
		</div>
	</div>

<?php endif; ?>	 
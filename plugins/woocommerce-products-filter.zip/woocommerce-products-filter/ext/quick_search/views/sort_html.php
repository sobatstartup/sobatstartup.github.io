<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>

<span class='woof_qt_sort_wraper'>
    <span class="woof_qt_sort_item" data-order="<?php echo esc_attr($asc) ?>">&#9650;</span>
    <span class="woof_qt_sort_item" data-order="<?php echo esc_attr($desc) ?>">&#9660;</span>
</span>


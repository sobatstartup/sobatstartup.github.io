<div class="woof-sd-ie woof-sd-ie-radio woof-sd-ie-radio___TERM_ID__ __CLASS__">
    <input type="radio" hidden id="__ID__"
           data-tax="__DATA_TAX__"
           name="__SLUG__" data-term-id="__TERM_ID__"
           value="__VALUE__" __CHECKED__ __DISABLED__
           onchange="woof_radio_direct_search(__TERM_ID__, '__DATA_TAX__', '__SLUG__')"
           hidden
           />
    <label for="__ID__">
        <span></span>
        __RESET_RADIO_BTN__
    </label>

    <b class="woof-sd-ie-title" onclick="this.parentNode.querySelector('label').click();" for="__ID__">__CONTENT__ <span class="woof-sd-ie-count">__COUNT__</span> __OPENER__</b>
    <input type="hidden" value="__TERM_NAME__" data-anchor="woof_n___DATA_ANCHOR__" />
</div>
<div class="woof-sd-ie woof-sd-ie-color woof-sd-ie-color___TERM_ID__ __CLASS__ woof-sd-tooltip __CLASS_HAS_IMAGE__" style="
     --woof-sd-ie-clr_color: __COLOR__;
     --woof-sd-ie-clr_image: url(__IMAGE__);
     ">
    <input type="radio" hidden id="__ID__"
           data-tax="__DATA_TAX__"
           name="__SLUG__" data-term-id="__TERM_ID__"
           value="__VALUE__" __CHECKED__ __DISABLED__
           onchange="woof_radio_direct_search(__TERM_ID__, '__DATA_TAX__', '__SLUG__')"
           hidden
           />
    <label for="__ID__"><span></span><b class="woof-sd-ie-count">__COUNT__</b></label>
    <input type="hidden" value="__TERM_NAME__" data-anchor="woof_n___DATA_ANCHOR__" />

    __TOOLTIP_TEXT__
    __RESET_RADIO_BTN__
</div>
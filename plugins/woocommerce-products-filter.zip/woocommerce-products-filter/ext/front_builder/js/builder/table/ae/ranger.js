'use strict';
import Ranger23 from '../../lib/ranger.js';
export default Ranger23;

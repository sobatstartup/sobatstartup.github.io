<?php if (!defined('ABSPATH')) die('No direct access allowed'); 
?>
<div class="woof_show_mobile_filter_container"></div>

<?php
/**
 * widget base for Sobat StartUp Extensions
 *
 * @author     Sobat StartUp
 * @package    Sobat StartUp Extensions
 * @license    GNU General Public License V3
 */

abstract class SoStar_Widget extends WP_Widget {
	
	public $template;
	abstract function getTemplate();

	public function display( $args, $instance ) {
		$this->getTemplate();
		extract($args);
		extract($instance);
		echo $before_widget;
			require sobat_startup_extensions_get_widget_locate( $this->template );
		echo $after_widget;
	}
}
<?php 
    $author                     = rwmb_get_value( 'sostar_portfolio_author' );
    $date                       = rwmb_get_value( 'sostar_portfolio_date' );
    $skills                     = rwmb_get_value( 'sostar_portfolio_skills' );
    $client                     = rwmb_get_value( 'sostar_portfolio_client_name' );
    $url                        = rwmb_get_value( 'sostar_portfolio_project_url' );
    $short_description          = rwmb_get_value( 'sostar_portfolio_short_description' );
    $gallery_image              = rwmb_meta( 'sostar_portfolio_gallery_image', ['size' => 'thumbnail'] );
    add_action( 'wp_footer', 'lasa_photoswipe' );

    wp_enqueue_script('photoswipe');
    wp_enqueue_script('photoswipe-ui-default');
   
    wp_enqueue_style('photoswipe');
    wp_enqueue_style('photoswipe-default-skin');
?>
<div class="pf-image-wrap clearfix">
    <div class="pf-image">
        <?php
            the_post_thumbnail('full');
          ?>
    </div>

    <div class="pf-informations">
        <h1 class="info-title"><?php the_title(); ?></h1>
        <table class="list-info">
            <?php 
                if( !empty($author) ) {
                    echo '<tr><td class="first">'. esc_html__('Created by: ', 'sobat-startup-extensions') .'</td><td>'. $author .'</td></tr>';
                }

                if( !empty($date) ) {
                    echo '<tr><td class="first">'. esc_html__('Date: ', 'sobat-startup-extensions') .'</td><td>'. $date .'</td></tr>';
                }

                if( !empty($skills) ) {
                    echo '<tr><td class="first">'. esc_html__('Skills: ', 'sobat-startup-extensions') .'</td><td>'. $skills .'</td></tr>';
                }

                if( !empty($client) ) {
                    echo '<tr><td class="first">'. esc_html__('Client:  ', 'sobat-startup-extensions') .'</td><td>'. $client .'</td></tr>';
                }

                if( !empty($url) ) {
                    echo '<tr><td class="first">'. esc_html__('Demo:  ', 'sobat-startup-extensions') .'</td><td><a target="_blank" href="'. esc_url($url) .'">'. esc_html__('See Demo', 'sobat-startup-extensions') .'</a></td></tr>';
                }
            ?>
        </table>

        <?php 
            if( !empty($short_description) ) {
                echo '<div class="pf-short-description">'. $short_description .'</div>';
            }
        ?>
    </div>
</div>

<div class="pf-desc">
    <?php the_content(); ?>
</div>

<?php 
    if( !empty($gallery_image) ) {
        echo '<div id="pf-gallery-images">';
            echo '<h3 class="gallery-heading"><span>'. esc_html__('Project Gallery', 'lasa') .'</span></h3>';

                $settings = apply_filters('portfolio_single_gallery_filter', 
                array(
                    'items' => 4,
                    'desktopslick' => 4,
                    'desktopsmallslick' => 4,
                    'tabletslick' => 3,
                    'landscapeslick' => 3,
                    'mobileslick' => 2,
                    'rows' => 1,
                    'nav' => true,
                    'pagination' => false,
                    'loop' => false,
                    'auto' => true,
                    'unslick' => false,
                    'autospeed' => 500,
                ));

                $rows           = $settings['rows'];
                $nav_type       = $settings['nav'];
                $pagi_type      = $settings['pagination'];
                $loop_type      = $settings['loop'];
                $auto_type      = $settings['auto'];
                $autospeed_type = $settings['autospeed'];
                $columns        = $settings['items'];
                $screen_desktop = $settings['desktopslick'];
                $screen_desktopsmall = $settings['desktopsmallslick'];
                $screen_tablet          = $settings['tabletslick'];
                $screen_landscape_mobile = $settings['landscapeslick'];
                $screen_mobile          = $settings['mobileslick'];
                $disable_mobile          = $settings['unslick'];

                $data_carousel = lasa_sostar_data_carousel($rows, $nav_type, $pagi_type, $loop_type, $auto_type, $autospeed_type, $disable_mobile);
                $responsive_carousel  = lasa_sostar_check_data_responsive_carousel($columns, $screen_desktop, $screen_desktopsmall, $screen_tablet, $screen_landscape_mobile, $screen_mobile);
            ?>
            <div class="owl-carousel pf-gallery-slick rows-<?php echo esc_attr($rows); ?>" <?php echo trim($responsive_carousel); ?>  <?php echo trim($data_carousel); ?> >
                <?php
                foreach ($gallery_image as $image) {
                    ?>
                    <div class="item">
                        <?php 
                            $image_alt          = get_post_meta($image['ID'], '_wp_attachment_image_alt', true);
                            $image_data         = wp_get_attachment_metadata( $image['ID'] );
                            $img_src            =  $image['full_url'];
                            $width 		        = $image_data['width'];
                            $height 	        = $image_data['height'];

                            echo '<a class="gallery-link" href="'. esc_url($img_src) .'" data-width="'. esc_attr($width) .'" data-height="'. esc_attr($height) .'"><img class="gallery-images"
                            src="' . esc_url($img_src) .'" alt="'. $image_alt .'"/></a>';
                        ?>
                    </div>
                    <?php
                }
            echo '</div>';
        echo '</div>';
    }
?>

<div class="pf-navigation">
    <?php lasa_sostar_post_nav(); ?>
</div>

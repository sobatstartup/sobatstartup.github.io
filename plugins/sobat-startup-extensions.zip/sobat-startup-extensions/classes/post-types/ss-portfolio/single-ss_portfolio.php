<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header(); 

lasa_sostar_render_breadcrumbs();
?>
<section id="main-container" class="main-content container">
	<div class="row ss-custom-portfolio ">
		<div id="main-content" class="col-xxl-9 mx-auto ">
			<div id="content" class="site-content single-portfolio">
				<?php 
					sobat_startup_extensions_portfolio_get_template( 'content-single.php' ); //override in theme ss-portfolio/content-archive.php
				?>
			</div>
		</div>
	</div>
</section>
<?php
get_footer();

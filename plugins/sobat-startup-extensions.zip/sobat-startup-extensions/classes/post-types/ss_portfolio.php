<?php
/**
 * Footer manager for Sobat StartUp Extensions
 *
 * @author     Sobat StartUp
 * @package    Sobat StartUp Extensions
 * @license    GNU General Public License V3
 */
 
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

class SoStar_Portfolio {

	/**
	 * Instance of SoStar_Portfolio
	 *
	 * @var SoStar_Portfolio
	 */
	private static $_instance = null;

	/**
	 * Instance of SoStar_Portfolio
	 *
	 * @return SoStar_Portfolio Instance of SoStar_Portfolio
	 */
	public static function instance() {
		if ( ! isset( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}


	/**
	 * Constructor
	 */
	private function __construct() {
    	add_action( 'init', array( $this, 'register_post_type' ) );
    	add_action( 'init', array( $this, 'register_taxonomy' ) );
    	add_action( 'admin_init', array( $this, 'add_role_caps' ) );
  	} 
	  
  	public static function register_post_type() {
	    $labels = array(
			'name' => 'Portfolios',
			'singular_name' => 'Portfolio',
			'menu_name' => 'Portfolios',
			'all_items' => esc_html__( 'All Portfolios','sobat-startup-extensions' ), 
			'edit_item' => esc_html__( 'Edit Portfolio','sobat-startup-extensions' ),
			'view_item' => esc_html__( 'View Portfolio','sobat-startup-extensions' ),
			'view_items' => esc_html__( 'View Portfolios','sobat-startup-extensions' ),
			'add_new_item' => esc_html__( 'Add New Portfolio','sobat-startup-extensions' ),
			'add_new' => esc_html__( 'Add New Portfolio','sobat-startup-extensions' ),
			'new_item' => esc_html__( 'New Portfolio','sobat-startup-extensions' ),
			'parent_item_colon' => esc_html__( 'Parent Portfolio:','sobat-startup-extensions' ),
			'search_items' => esc_html__( 'Search Portfolios','sobat-startup-extensions' ),
			'not_found' => esc_html__( 'No Portfolios found','sobat-startup-extensions' ),
			'not_found_in_trash' => esc_html__( 'No Portfolios found in Trash','sobat-startup-extensions' ),
			'archives' => esc_html__( 'Portfolio Archives','sobat-startup-extensions' ),
			'attributes' => esc_html__( 'Portfolio Attributes','sobat-startup-extensions' ),
			'insert_into_item' => esc_html__( 'Insert into Portfolio','sobat-startup-extensions' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to this Portfolio','sobat-startup-extensions' ),
			'filter_items_list' => esc_html__( 'Filter Portfolios list','sobat-startup-extensions' ),
			'filter_by_date' => esc_html__( 'Filter Portfolios by date','sobat-startup-extensions' ),
			'items_list_navigation' => esc_html__( 'Portfolios list navigation','sobat-startup-extensions' ),
			'items_list' => esc_html__( 'Portfolios list','sobat-startup-extensions' ),
			'item_published' => esc_html__( 'Portfolio published.','sobat-startup-extensions' ),
			'item_published_privately' => esc_html__( 'Portfolio published privately.','sobat-startup-extensions' ),
			'item_reverted_to_draft' => esc_html__( 'Portfolio reverted to draft.','sobat-startup-extensions' ),
			'item_scheduled' => esc_html__( 'Portfolio scheduled.','sobat-startup-extensions' ),
			'item_updated' => esc_html__( 'Portfolio updated.','sobat-startup-extensions' ),
			'item_link' => esc_html__( 'Portfolio Link','sobat-startup-extensions' ),
	    ); 

	    $type = 'ss_portfolio';
 
	    register_post_type( $type,
	      	array(
		        'labels'            => apply_filters( 'sostar_postype_portfolio' , $labels ),
				'public' => true,
				'show_in_rest' => true,
				'supports' => array(
					0 => 'title',
					1 => 'editor',
					2 => 'thumbnail',
				),
				'delete_with_user' => false,
				'menu_icon' 		=> 'dashicons-schedule',
		        'menu_position'     => 52,
				'has_archive' => false,
				'capability_type'   => array($type, "{$type}s"),
				'map_meta_cap'      => true,	   
				'rewrite' => array('slug' => apply_filters( 'sostar_postype_portfolio_rewrite_slug', 'portfolio' )),   	
			)
	    );

  	}

	public static function register_taxonomy() {
	    $labels = array(
			'name' => 'Tags',
			'singular_name' => 'tag',
			'menu_name' => 'Tags',
			'all_items' => esc_html__( 'All Tags','sobat-startup-extensions' ),
			'edit_item' => esc_html__( 'Edit Tag','sobat-startup-extensions' ),
			'view_item' => esc_html__( 'View Tag','sobat-startup-extensions' ),
			'update_item' => esc_html__( 'Update Tag','sobat-startup-extensions' ),
			'add_new_item' => esc_html__( 'Add New Tag','sobat-startup-extensions' ),
			'new_item_name' => esc_html__( 'New Tag Name','sobat-startup-extensions' ),
			'search_items' => esc_html__( 'Search Tags','sobat-startup-extensions' ),
			'popular_items' => esc_html__( 'Popular Tags','sobat-startup-extensions' ),
			'separate_items_with_commas' => esc_html__( 'Separate Tags with commas','sobat-startup-extensions' ),
			'add_or_remove_items' => esc_html__( 'Add or remove Tags','sobat-startup-extensions' ),
			'choose_from_most_used' => esc_html__( 'Choose from the most used Tags','sobat-startup-extensions' ),
			'not_found' => esc_html__( 'No Tags found','sobat-startup-extensions' ),
			'no_terms' => esc_html__( 'No Tags','sobat-startup-extensions' ),
			'items_list_navigation' => esc_html__( 'Tags list navigation','sobat-startup-extensions' ),
			'items_list' => esc_html__( 'Tags list','sobat-startup-extensions' ),
			'back_to_items' => esc_html__( '← Go to Tags','sobat-startup-extensions' ),
			'item_link' => esc_html__( 'Tags Link','sobat-startup-extensions' ),
			'item_link_description' => esc_html__( 'A link to a Tag','sobat-startup-extensions' ),
	    ); 

	    $type = 'portfolio-tag';
 
	    register_taxonomy( $type,
			array(
				0 => 'ss_portfolio',
			),
	      	array(
		        'labels'   => apply_filters( 'sostar_postype_portfolio_tag' , $labels ),
				'public' => true,
				'show_in_menu' => false,
				'show_in_rest' => true,      	
			)
	    );

  	}

  	public static function add_role_caps() {
 
		 // Add the roles you'd like to administer the custom post types
		 $roles = array('administrator');

		 $type  = 'ss_portfolio';
		 
		 // Loop through each role and assign capabilities
		 foreach($roles as $the_role) { 
		 
		    $role = get_role($the_role);
		 
			$role->add_cap( "read" );
			$role->add_cap( "read_{$type}");
			$role->add_cap( "read_private_{$type}s" );
			$role->add_cap( "edit_{$type}" );
			$role->add_cap( "edit_{$type}s" );
			$role->add_cap( "edit_others_{$type}s" );
			$role->add_cap( "edit_published_{$type}s" );
			$role->add_cap( "publish_{$type}s" );
			$role->add_cap( "delete_others_{$type}s" );
			$role->add_cap( "delete_private_{$type}s" ); 
			$role->add_cap( "delete_published_{$type}s" );
		 
		 }
	}
}

SoStar_Portfolio::instance();
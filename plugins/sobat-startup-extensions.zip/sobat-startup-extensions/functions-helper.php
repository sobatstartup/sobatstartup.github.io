<?php
/**
 * Functions for Sobat StartUp Extensions
 *
 * @author     Sobat StartUp
 * @package    Sobat StartUp Extensions
 * @license    GNU General Public License V3
 */

if( ! function_exists( 'sobat_startup_extensions_get_widget_locate' ) ) {
    function sobat_startup_extensions_get_widget_locate( $name, $plugin_dir = SOBAT_STARTUP_EXTENSIONS_ELEMENTOR_DIR ) {
    	$template = '';
    	
    	// Child theme
    	if ( ! $template && ! empty( $name ) && file_exists( get_stylesheet_directory() . "/widgets/{$name}" ) ) {
    		$template = get_stylesheet_directory() . "/widgets/{$name}";
    	}

    	// Original theme
    	if ( ! $template && ! empty( $name ) && file_exists( get_template_directory() . "/widgets/{$name}" ) ) {
    		$template = get_template_directory() . "/widgets/{$name}";
    	}

    	// Plugin
    	if ( ! $template && ! empty( $name ) && file_exists( $plugin_dir . "/templates/widgets/{$name}" ) ) {
    		$template = $plugin_dir . "/templates/widgets/{$name}";
    	}

    	// Nothing found
    	if ( empty( $template ) ) {
    		throw new Exception( "Template /templates/widgets/{$name} in plugin dir {$plugin_dir} not found." );
    	}

    	return $template;
    }
}

if( ! function_exists( 'sobat_startup_extensions_single_template' ) ) {
	add_filter( 'single_template', 'sobat_startup_extensions_single_template' );
	function sobat_startup_extensions_single_template( $single_template ){
		global $post;

		if( $post->post_type === 'ss_portfolio' ) {
			$file = dirname(__FILE__) .'/classes/post-types/ss-portfolio/single-'. $post->post_type .'.php';
			if( file_exists( $file ) ) $single_template = $file;
		}

		return $single_template;
	}
}

if( ! function_exists( 'sobat_startup_extensions_archive_template' ) ) {
	add_filter( 'archive_template', 'sobat_startup_extensions_archive_template' );
	function sobat_startup_extensions_archive_template( $single_template ){
		global $post;

		if( $post->post_type === 'ss_portfolio' ) {
			$file = dirname(__FILE__) .'/classes/post-types/ss-portfolio/archive-'. $post->post_type .'.php';
			if( file_exists( $file ) ) $single_template = $file;
		}

		return $single_template;
	}
}

if( ! function_exists( 'sobat_startup_extensions_portfolio_locate_template' ) ) {

	function sobat_startup_extensions_portfolio_locate_template( $path, $var = null ) {
		$template_path             = 'ss-portfolio/' . $path;
		$plugin_path               = SOBAT_STARTUP_EXTENSIONS_ELEMENTOR_DIR . 'classes/post-types/ss-portfolio/' . $path;

		$located = locate_template(
			array(
				$template_path,             // Search in <theme>/.
			)
		);

		if ( ! $located && file_exists( $plugin_path ) ) {
			return apply_filters( 'sobat_startup_extensions_portfolio_locate_template', $plugin_path, $path );
		}

		/**
		 * APPLY_FILTERS: sobat_startup_extensions_portfolio_locate_template
		 *
		 * Filter the location of the templates.
		 *
		 * @param string $located Template found
		 * @param string $path    Template path
		 *
		 * @return string
		 */
		return apply_filters( 'sobat_startup_extensions_portfolio_locate_template', $located, $path );
	}
}

if( ! function_exists( 'sobat_startup_extensions_portfolio_get_template' ) ) {
	function sobat_startup_extensions_portfolio_get_template( $path, $var = null, $return = false ) { // phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.varFound, Universal.NamingConventions.NoReservedKeywordParameterNames.returnFound
		$located = sobat_startup_extensions_portfolio_locate_template( $path, $var );

		if ( $var && is_array( $var ) ) {
			$atts = $var;
			extract( $var ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
		}

		if ( $return ) {
			ob_start();
		}

		// include file located.
		include $located;

		if ( $return ) {
			return ob_get_clean();
		}
	}
}
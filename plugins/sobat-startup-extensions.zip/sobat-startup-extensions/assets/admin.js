jQuery(document).ready(function ($) {
	var sostar_hide_shortcode_field = function() {
		var selected = jQuery('#sostar_block_type').val() || 'none';
		jQuery( '.sostar-options-table' ).removeClass().addClass( 'sostar-options-table widefat sostar-selected-template-type-' + selected );
	}

	jQuery(document).on( 'change', '#sostar_block_type', function( e ) {
		sostar_hide_shortcode_field();
	});

	sostar_hide_shortcode_field();
});

jQuery(document).ready(function ($) {
	var sostex_hide_shortcode_field = function() {
		var selected = jQuery('#sostex_block_type').val() || 'none';
		jQuery( '.sostex-options-table' ).removeClass().addClass( 'sostex-options-table widefat sostex-selected-template-type-' + selected );
	}

	jQuery(document).on( 'change', '#sostex_block_type', function( e ) {
		sostex_hide_shortcode_field();
	});

	sostex_hide_shortcode_field();
});
